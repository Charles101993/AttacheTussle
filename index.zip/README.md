# 315-game-SweatBoys

Group Members: Dan Banks, Charles Beehner, Taylor Stephenson, Victor Meniola

You must be on the tamu server when you run the game on compute.  
To run the game you must have node.js installed.  
https://nodejs.org/en/

**To run:**  
Log into *compute.cse.tamu.edu* on putty.  
Type *node app.js* into command line.  
The server will start.  
On google chrome, go to *compute-linux1.cs.tamu.edu:10000* to start the game.

**To test:**  
If testing on the same computer run the game in two separate windows.  
